//
//  FrontViewController.m
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-7-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "FrontViewController.h"
#import "PageModel.h"
#import "CustomTextField.h"
#import "CustomLabel.h"
#import "CustomWebView.h"
#import "CustomToolbar.h"
#import "CustomTableView.h"
#import "Reachability.h"
#import "HistoryDAL.h"
#import "FavouriteDAL.h"
#import "FileTranserHelper.h"
#import "FileTranserModel.h"


@interface FrontViewController ()

-(void)goBack:(id)sender;
-(void)goForward:(id)sender;
-(void)goHome:(id)sender;
-(void)goRefresh:(id)sender;
-(void)goStop:(id)sender;
-(void)addFavourite:(id)sender;
-(void)isShowControls:(BOOL)flag;
-(void)updateBarState:(NSString *)url;
-(NSString *)getPageIconFromURL:(NSString *)url;

-(void)removeActivityView;
@end

@implementation FrontViewController

@synthesize webView,txtSite,lbl3,lbl4,lbl5;
@synthesize contentlist;
@synthesize navBar,bottomTb;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
           }
    return self;
}

#pragma  private Method

-(void)goBack:(id)sender
{
    [webView goBack];
}

-(void)goForward:(id)sender
{
    [webView goForward];
}

-(void)goHome:(id)sender
{
    [webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"http://www.google.com"]]];
}

-(void)goRefresh:(id)sender
{
    [webView reload];
}

-(void)goStop:(id)sender
{
    [webView stopLoading];
    //停止
    UIBarButtonItem *stopItem=[bottomTb.items objectAtIndex:8];
    [stopItem setEnabled:NO];
}

-(void)addFavourite:(id)sender
{
    NSString *currentURL=[webView.request.URL description];
    
    if([[FavouriteDAL sharedInstance] isAdded:currentURL])
    {
        [[FileTranserHelper sharedInstance] showNotification:@"该网址已加入收藏夹了"];
        return;
    }
    
    //历史记录
    NSString *title=[webView stringByEvaluatingJavaScriptFromString:@"document.title"];
    PageModel *pageModel=[[PageModel alloc] init];
    pageModel.pageTitle=title;
    
    pageModel.pageIconURL=[self getPageIconFromURL:currentURL];
    pageModel.pageURL=[txtSite.text lowercaseString];
    pageModel.creationDate=[NSDate date];
    [contentlist addObject:pageModel];
    [[FavouriteDAL sharedInstance] insertOneFavourite:pageModel];
    [pageModel release];
    [[FileTranserHelper sharedInstance] showNotification:@"添加收藏夹成功"];
}

-(void)isShowControls:(BOOL)flag
{
    [navBar setHidden:!flag];
    [webView setHidden:!flag];
    [bottomTb setHidden:!flag];
}

-(void)loadView
{
    [super loadView];
    
    webView=[[CustomWebView alloc] initWithFrame:CGRectMake(0, 60, self.view.frame.size.width, self.view.frame.size.height-60-44)];
    [webView setDelegate:self];
    [webView setScalesPageToFit:YES];
    [self.view addSubview:webView];
    
    for(UIView *view in webView.subviews)
    {
        if([view isKindOfClass:[UIScrollView class]])
        {
            [(UIScrollView *)view setDelegate:self];
        }
    }
    
    
    
    navBar=[[CustomNavBar alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 60)];
    if([[[UIDevice currentDevice] systemVersion] intValue]>=5)
    {
        [navBar setBackgroundImage:[UIImage imageNamed:@"top_bg.png"] forBarMetrics:UIBarMetricsDefault];
    }
    CustomLabel *lblTitle=[[CustomLabel alloc] initWithFrame:CGRectMake(0, 2, self.view.frame.size.width, 22)];
    [lblTitle setBackgroundColor:[UIColor clearColor]];
    [lblTitle setTextColor:[UIColor whiteColor]];
    [lblTitle setFont:[UIFont boldSystemFontOfSize:17]];
    [lblTitle setTextAlignment:UITextAlignmentCenter];
    [lblTitle setText:@""];
    [lblTitle setTag:500];
    [navBar addSubview:lblTitle];
    [self.view addSubview:navBar];
    [lblTitle release];
    
    
    self.txtSite=[[[UITextField alloc] initWithFrame:CGRectMake(10,25, self.view.frame.size.width-20, 27)] autorelease];
    [txtSite setBorderStyle:UITextBorderStyleRoundedRect];
    [txtSite setTextColor:[UIColor grayColor]];
    [txtSite setDelegate:self];
    [txtSite setAutocapitalizationType:UITextAutocapitalizationTypeNone];
    [txtSite setFont:[UIFont systemFontOfSize:16]];
    txtSite.clearButtonMode=UITextFieldViewModeWhileEditing;
    txtSite.returnKeyType=UIReturnKeySearch;
    [navBar addSubview:txtSite];
    
    UIButton *btnRefresh=[UIButton buttonWithType:UIButtonTypeCustom];
    [btnRefresh setFrame:CGRectMake(0, 0, 19, 19)];
    [btnRefresh setBackgroundImage:[UIImage imageNamed:@"refresh.png"] forState:UIControlStateNormal];
    [btnRefresh addTarget:self action:@selector(goRefresh:) forControlEvents:UIControlEventTouchUpInside];
    txtSite.rightView=btnRefresh;
    txtSite.rightViewMode=UITextFieldViewModeUnlessEditing;

    

    bottomTb=[[CustomToolbar alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height-44, self.view.frame.size.width, 44)];
    [bottomTb setTintColor:[UIColor blueColor]];
    if([[UIDevice currentDevice] userInterfaceIdiom]==UIUserInterfaceIdiomPhone)
    {
        if([[[UIDevice currentDevice] systemVersion] intValue]>=5)
        {
            [bottomTb setBackgroundImage:[UIImage imageNamed:@"station_tab.png"] forToolbarPosition:UIToolbarPositionBottom barMetrics:UIBarMetricsDefault];
        }
    }
    else
    {
        if([[[UIDevice currentDevice] systemVersion] intValue]>=5)
        {
            [bottomTb setBackgroundImage:[UIImage imageNamed:@"toolbar_bg_iPad.png"] forToolbarPosition:UIToolbarPositionBottom barMetrics:UIBarMetricsDefault];
        }
    }
    NSMutableArray *tbitems=[NSMutableArray array];
    
    UIBarButtonItem *backItem=[[[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"station_back.png"] style:UIBarButtonItemStylePlain target:self action:@selector(goBack:)] autorelease];
    [backItem setTag:1000];
    [backItem setEnabled:NO];
    
    UIBarButtonItem *forwardItem=[[[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"station_forward.png"] style:UIBarButtonItemStylePlain target:self action:@selector(goForward:)] autorelease];
    [forwardItem setTag:1001];
    [forwardItem setEnabled:NO];
    
    UIBarButtonItem *homeItem=[[[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"station_home.png"] style:UIBarButtonItemStylePlain target:self action:@selector(goHome:)] autorelease];
    [forwardItem setTag:1002];
    
    UIBarButtonItem *refreshItem=[[[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"favoriteicon.png"] style:UIBarButtonItemStylePlain target:self action:@selector(addFavourite:)] autorelease];
    [refreshItem setWidth:57];
    [forwardItem setTag:1003];
    
    UIBarButtonItem *closeItem=[[[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"station_close.png"] style:UIBarButtonItemStylePlain target:self action:@selector(goStop:)] autorelease];
    [forwardItem setTag:1004];
    [closeItem setEnabled:NO];
    
    UIBarButtonItem *spaceItem=[[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:self action:nil] autorelease];
    [tbitems setArray:[NSArray arrayWithObjects:backItem,spaceItem,forwardItem,spaceItem,homeItem,spaceItem,refreshItem,spaceItem,closeItem, nil]];
    
    bottomTb.items=tbitems;
    [self.view addSubview:bottomTb];
    
    
    contentlist=[[NSMutableArray alloc] init];
    PageModel *pageModel=[[PageModel alloc] init];
    pageModel.pageURL=@"http://www.google.com";
    pageModel.pageContent=@"";
    [contentlist addObject:pageModel];
    [pageModel release];

    txtSite.text=pageModel.pageURL;
    
    NSURL *url=[NSURL URLWithString:pageModel.pageURL];
//    ASIHTTPRequest *request=[ASIHTTPRequest requestWithURL:url];
//    [request setDelegate:self];
//    [request startAsynchronous];
    [webView loadRequest:[NSURLRequest requestWithURL:url]];
    
}

//-(void)request:(ASIHTTPRequest *)request didReceiveResponseHeaders:(NSDictionary *)responseHeaders
//{
//    NSLog(@"responseHeaders=%@",responseHeaders);
//}
//-(void)request:(ASIHTTPRequest *)request didReceiveData:(NSData *)data
//{
//    NSString *html=[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
//    NSLog(@"%@",html);
//    [webView loadHTMLString:html baseURL:request.url];
//}

-(void)releaseCache
{
    self.webView=nil;
    self.navBar=nil;
    self.bottomTb=nil;
}

-(void)dealloc
{
    [self releaseCache];
    self.contentlist=nil;
    [super dealloc];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    [self releaseCache];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self isShowControls:YES];
}

-(void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    [self isShowControls:NO];

}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma textfield delegate
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if([textField.text length]==0)
    {
        return YES;
    }
    [textField resignFirstResponder];
    NSUInteger startIndex=[textField.text rangeOfString:@"www"].location;
    if(startIndex!=NSNotFound)
    {
        NSString *targetSite=[textField.text substringFromIndex:startIndex];
        textField.text=[NSString stringWithFormat:@"http://%@",targetSite];
        textField.text=[textField.text lowercaseString];
    }
    
    
    if(![Reachability connectedToNetwork])
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"温馨提示" message:@"网络异常" delegate:nil cancelButtonTitle:@"好" otherButtonTitles:nil];
        [alert show];
        [alert release];
        return YES;
    }

    [webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:textField.text]]];

    return YES;
}

-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    isEditing=YES;
    [txtSite setTextColor:[UIColor blackColor]];
}

-(void)textFieldDidEndEditing:(UITextField *)textField
{
    isEditing=NO;
    [txtSite setTextColor:[UIColor grayColor]];
    if([contentlist count]>0&&[textField.text length]==0)
    {
        PageModel *pageModel=[contentlist objectAtIndex:[contentlist count]-1];
        [txtSite setText:pageModel.pageURL];
    }
}


#pragma asihttpe - delegate
//判断是否是文件
-(BOOL)isFile:(NSString *)mime
{
    NSURL *url=[[[NSBundle mainBundle] resourceURL] URLByAppendingPathComponent:@"Suffix.plist"];
    NSDictionary *rootDict=[[[NSDictionary alloc] initWithContentsOfURL:url] autorelease];//总目录字典
    for(NSString *key in [rootDict allKeys])
    {
        NSDictionary *typeDict=[rootDict objectForKey:key];//每个类型字典
        NSDictionary *suffixDict=[typeDict objectForKey:@"Suffix"];//每个类型下的后缀字典
        for(NSString *suffix in [suffixDict allKeys])
        {
            NSString *valueMime=[suffixDict objectForKey:suffix];
            if([valueMime isEqualToString:mime])
            {
                return YES;
            }
        }
    }
    return NO;
}

-(void)updateBarState:(NSString *)url
{
    //后退
    UIBarButtonItem *backItem=[bottomTb.items objectAtIndex:0];
    [backItem setEnabled:[webView canGoBack]];
    
    //前进
    UIBarButtonItem *forwardItem=[bottomTb.items objectAtIndex:2];
    [forwardItem setEnabled:[webView canGoForward]];
    
    //停止
    UIBarButtonItem *stopItem=[bottomTb.items objectAtIndex:8];
    [stopItem setEnabled:[webView isLoading]];

    //标题
    CustomLabel *lblTitle=(CustomLabel *)[navBar viewWithTag:500];
    lblTitle.text = [webView stringByEvaluatingJavaScriptFromString:@"document.title"];
    if([[webView.request.URL description] length]!=0&&!isEditing)
    {
        txtSite.text=url;
    }
}

#pragma webView delegate
-(BOOL)webView:(UIWebView *)_webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{    
    [self updateBarState:[request.URL description]];
    return YES;
}

-(void)webViewDidStartLoad:(UIWebView *)_webView
{   
    UIActivityIndicatorView *actView=[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    [actView setFrame:CGRectMake(0, 0, 25, 25)];
    [actView setCenter:webView.center];
    [actView startAnimating];
    [_webView addSubview:actView];
    [actView release];
 
    NSURLConnection *conn=[[[NSURLConnection alloc] initWithRequest:[NSURLRequest requestWithURL:_webView.request.URL] delegate:self] autorelease];
    [conn start];
}

-(void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
//    NSString *mimeType=[[response MIMEType] objectForKey:@"Content-Type"];
    if([self isFile:[response MIMEType]])
    {
        FileTranserModel *file=[[FileTranserModel alloc] init];
        file.downoadUrl=[response.URL description];
        file.fileName=response.suggestedFilename;
        file.fileTrueSize=response.expectedContentLength;
        [[FileTranserHelper sharedInstance] startDownloadFile:file delegate:nil];
        [file release];
    }
}

-(void)removeActivityView
{
    for(UIActivityIndicatorView *actView in [webView subviews])
    {
        if([actView isKindOfClass:[UIActivityIndicatorView class]])
        {
            [actView removeFromSuperview];
        }
    }
}

-(NSString *)getPageIconFromURL:(NSString *)url
{
    if(url.length>7)
    {
        NSString *url1=[url substringFromIndex:7];
        NSUInteger index1=[url1 rangeOfString:@"/"].location;
        if(index1<1000)
        {
            NSString *url2=[url1 substringToIndex:index1];
            return [NSString stringWithFormat:@"http://%@/favicon.ico",url2];
        }
    }
    return nil;
}

-(void)webViewDidFinishLoad:(UIWebView *)_webView
{
    [self removeActivityView];
    [self updateBarState:[_webView.request.URL description]];


    //历史记录
    NSString *title=[webView stringByEvaluatingJavaScriptFromString:@"document.title"];
    PageModel *pageModel=[[PageModel alloc] init];
    pageModel.pageTitle=title;
    
    pageModel.pageIconURL=[self getPageIconFromURL:[_webView.request.URL description]];
    pageModel.pageURL=[_webView.request.URL description];
    pageModel.creationDate=[NSDate date];
    [contentlist addObject:pageModel];
    [[HistoryDAL sharedInstance] insertOneHistory:pageModel];
    [pageModel release];
}

-(void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    [self removeActivityView];
}

#pragma mark ScrollView delegate
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if(scrollView.contentOffset.y<-150)
    {
    }
    NSLog(@"%f",scrollView.contentOffset.y);
}


-(void)cubeStateDidChanged:(CubeView *)cubeView cubeState:(NSNumber *)cubeState
{
}

@end
