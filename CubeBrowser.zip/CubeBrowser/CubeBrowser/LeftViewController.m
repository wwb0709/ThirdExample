//
//  LeftViewController.m
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-7-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "LeftViewController.h"
#import "CustomTableView.h"
#import "HistoryDAL.h"
#import "PageModel.h"
#import "FavouriteDAL.h"
#import "UIImageView+WebCache.h"
#import "MBProgressHUD.h"

#define kHistrtyTableViewTag 500
#define kFavouriteTableViewTag 501
#define kHisttoryHeaderTag 503
#define kFavouriteHeaderTag 504

@interface LeftViewController ()


@property(nonatomic,retain)MBProgressHUD *hudView;
-(void)reloadDataInThreadByTag:(NSNumber *)tag;//通过表格的tag重新加载数据
-(void)reloadDataOnMainThreadByTag:(NSNumber *)tag;
-(void)deleteHistoryByIndex:(NSNumber *)index;
-(void)deleteFavouriteByIndex:(NSNumber *)index;
-(void)clearData;//清空历史或者收藏夹
-(void)clearDataInThread;
-(void)goHome;
@end

@implementation LeftViewController

@synthesize adBannerView;
@synthesize hisHeaderView;
@synthesize segmentController;
@synthesize hislist,favlist;
@synthesize hisTableView,favTableView;
@synthesize favHeaderView;
@synthesize hudView;
@synthesize delegate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)goHome
{
    if([delegate respondsToSelector:@selector(cubeStateDidChanged:cubeState:)])
    {
        [delegate cubeViewClick:[NSNumber numberWithInt:CubeLeftState] obj:nil];
    }
}
-(void)loadView
{
    [super loadView];
        
    [self.view setBackgroundColor:[UIColor grayColor]];
    
    
    //历史记录
    hisTableView=[[CustomTableView alloc] initWithFrame:CGRectMake(0, 32, self.view.frame.size.width, self.view.frame.size.height-44-32-44)];
    [hisTableView setTag:kHistrtyTableViewTag];
    [hisTableView setDataSource:self];
    [hisTableView setDelegate:self];
    [hisTableView setCubeState:CubeLeftState];
    [self.view addSubview:hisTableView];

    hisHeaderView=[[EGORefreshTableHeaderView alloc] initWithFrame:CGRectMake(0, -hisTableView.frame.size.height, hisTableView.frame.size.width, hisTableView.frame.size.height)];
    [hisHeaderView setDelegate:self];
    [hisHeaderView setTag:kHisttoryHeaderTag];
    [hisTableView addSubview:hisHeaderView];
    [hisHeaderView refreshLastUpdatedDate];

    
    
    
    //收藏夹
    favTableView=[[CustomTableView alloc] initWithFrame:CGRectMake(0, hisTableView.frame.origin.y, self.view.frame.size.width, hisTableView.frame.size.height)];
    [favTableView setTag:kFavouriteTableViewTag];
    [favTableView setDataSource:self];
    [favTableView setDelegate:self];
    [favTableView setCubeState:CubeLeftState];
    [self.view addSubview:favTableView];
    
    favHeaderView=[[EGORefreshTableHeaderView alloc] initWithFrame:CGRectMake(0, -favTableView.frame.size.height, favTableView.frame.size.width, hisTableView.frame.size.height)];
    [favHeaderView setDelegate:self];
    [favHeaderView setTag:kFavouriteHeaderTag];
    [favTableView addSubview:favHeaderView];
    [favHeaderView refreshLastUpdatedDate];

    
    //分段控件
    segmentController=[[CustomSegmentController alloc] initWithLabels:[NSArray arrayWithObjects:NSLocalizedString(@"历史记录", @""),NSLocalizedString(@"收藏夹",@""), nil] buttonWidth:k_seg_button_middle];
    [segmentController setFrame:CGRectMake(0, 0, self.view.frame.size.width, 32)];
    [segmentController setTypeClickDelegate:self];
    [self.view addSubview:segmentController];
    
    
    ADBannerView *bannerView=[[ADBannerView alloc] initWithFrame:CGRectMake(0, favTableView.frame.origin.y+favTableView.frame.size.height, self.view.frame.size.width, 44)];
    [bannerView setDelegate:self];
    [self.view addSubview:bannerView];
    
    
    UIButton *btnHome=[[[UIButton alloc] initWithFrame:CGRectMake(0, 0, 66, 32)] autorelease];
    [btnHome.titleLabel setFont:[UIFont boldSystemFontOfSize:13]];
    [btnHome setBackgroundImage:[UIImage imageNamed:@"account_button.png"] forState:UIControlStateNormal];
    [btnHome setTitle:NSLocalizedString(@"主页", @"") forState:UIControlStateNormal];
    [btnHome addTarget:self action:@selector(goHome) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.rightBarButtonItem=[[[UIBarButtonItem alloc] initWithCustomView:btnHome] autorelease];
    [btnHome release];

    
    //初始化控件
    [self TypeClick:[NSNumber numberWithInt:0]];
}

-(void)releaseData
{
    self.favHeaderView=nil;
    self.hisHeaderView=nil;
    self.segmentController=nil;
    self.favlist=nil;
    self.hislist=nil;
    self.favTableView=nil;
    self.hisTableView=nil;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    [self releaseData];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.view setHidden:NO];
}

-(void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    [self.view setHidden:YES];
}

-(void)dealloc
{
    self.adBannerView.delegate=nil;
    self.adBannerView=nil;
    self.delegate=nil;
    self.hudView.delegate=nil;
    self.hudView=nil;
    [self releaseData];
    [super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


#pragma mark tableViewDataSource
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(tableView.tag==kHistrtyTableViewTag)
    {
        return [hislist count];
    }
    else {
        return [favlist count];
    }
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier=@"Cell";
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(!cell)
    {
        cell=[[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier] autorelease];
        [cell setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
    }
    PageModel *pageMode=nil;
    if(tableView.tag==kHistrtyTableViewTag)
    {
        pageMode=[hislist objectAtIndex:indexPath.row];
    }
    else {
        pageMode=[favlist objectAtIndex:indexPath.row];
    }
    [cell.imageView setImageWithURL:[NSURL URLWithString:pageMode.pageIconURL]];
    cell.textLabel.text=pageMode.pageTitle;
    NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"MM-dd HH:mm:ss"];
    NSString *creationDateString=[dateFormatter  stringFromDate:pageMode.creationDate];
    [dateFormatter release];
    cell.detailTextLabel.text=[NSString stringWithFormat:@"%@ %@",creationDateString,pageMode.pageURL];
    return cell;
}


-(void)deleteHistoryByIndex:(NSNumber *)index
{
    NSAutoreleasePool *pool=[[NSAutoreleasePool alloc] init];
    [hislist removeObjectAtIndex:[index intValue]];
    [[HistoryDAL sharedInstance] updateHistorylist:hislist];
    [hisTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
    [pool release];
}

-(void)deleteFavouriteByIndex:(NSNumber *)index
{
    NSAutoreleasePool *pool=[[NSAutoreleasePool alloc] init];
    [favlist removeObjectAtIndex:[index intValue]];
    [[FavouriteDAL sharedInstance] updateFavouritelist:favlist];
    [favTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
    [pool release];
}


#pragma mark - tableView delegate
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    PageModel *page=nil;
    if(tableView.tag=kHistrtyTableViewTag)
    {
        page=[hislist objectAtIndex:indexPath.row];
    }
    else
    {
        page=[favlist objectAtIndex:indexPath.row];
    }
    if([delegate respondsToSelector:@selector(cubeStateDidChanged:cubeState:)])
    {
        [delegate cubeViewClick:[NSNumber numberWithInt:CubeLeftState] obj:page.pageURL];
    }
}

-(BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(editingStyle==UITableViewCellEditingStyleDelete)
    {
        self.hudView=[[[MBProgressHUD alloc] initWithView:self.view] autorelease];
        [hudView setLabelText:@"请稍后..."];
        [hudView setRemoveFromSuperViewOnHide:YES];
        [self.view addSubview:hudView];
        if(tableView.tag==kHistrtyTableViewTag)
        {
            [hudView showWhileExecuting:@selector(deleteHistoryByIndex:) onTarget:self withObject:[NSNumber numberWithInt:indexPath.row] animated:YES];
        }
        if(tableView.tag==kFavouriteTableViewTag)
        {
            [hudView showWhileExecuting:@selector(deleteFavouriteByIndex:) onTarget:self withObject:[NSNumber numberWithInt:indexPath.row] animated:YES];
        }
    }
}

-(void)clearData
{
    if(![hisTableView isHidden])   
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:NSLocalizedString(@"温馨提示", @"") message:NSLocalizedString(@"确定要清空历史记录？",@"") delegate:self cancelButtonTitle:NSLocalizedString(@"删除", @"") otherButtonTitles:NSLocalizedString(@"取消", @""), nil];
        [alert show];
        [alert release];
    }
    else {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:NSLocalizedString(@"温馨提示", @"") message:NSLocalizedString(@"确定要清空历史记录？",@"") delegate:self cancelButtonTitle:NSLocalizedString(@"删除", @"") otherButtonTitles:NSLocalizedString(@"取消", @""), nil];
        [alert show];
        [alert release];
    }
}

-(void)clearDataInThread
{
    NSAutoreleasePool *pool=[[NSAutoreleasePool alloc] init];
    if(![hisTableView isHidden])
    {
        [[HistoryDAL sharedInstance] clearHistory];
        [hislist removeAllObjects];
        [hisTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
    }
    else {
        [[FavouriteDAL sharedInstance] clearFavourite];
        [favlist removeAllObjects];
        [favTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
    }
    [pool release];
}

#pragma mark Alert Delegate
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex==0)
    {
        self.hudView=[[[MBProgressHUD alloc] initWithView:self.view] autorelease];
        [hudView setRemoveFromSuperViewOnHide:YES];
        [hudView setLabelText:@"请稍后..."];
        [self.view addSubview:hudView];
        [hudView showWhileExecuting:@selector(clearDataInThread) onTarget:self withObject:nil animated:YES];
    }
}

#pragma mark- TypeClick
-(void)TypeClick:(NSNumber *)index
{
    UIButton *btn=[[UIButton alloc] initWithFrame:CGRectMake(0, 0, 66, 32)];
    [btn.titleLabel setFont:[UIFont boldSystemFontOfSize:13]];
    [btn setBackgroundImage:[UIImage imageNamed:@"account_button.png"] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(clearData) forControlEvents:UIControlEventTouchUpInside];
    NSLog(@"[index intValue=%d",[index intValue]);
    switch ([index intValue]) {
        case 0:
            self.navigationItem.title=NSLocalizedString(@"历史记录", @"");
            [hisTableView setHidden:NO];
            [favTableView setHidden:YES];
            [btn setTitle:NSLocalizedString(@"清空历史", @"") forState:UIControlStateNormal];
            if(hislist==nil)
            {
                [NSThread detachNewThreadSelector:@selector(reloadDataInThreadByTag:) toTarget:self withObject:[NSNumber numberWithInt:kHisttoryHeaderTag]];
            }
            break;
        case 1:
            self.navigationItem.title=NSLocalizedString(@"收藏夹", @"");
            [hisTableView setHidden:YES];
            [favTableView setHidden:NO];
            [btn setTitle:NSLocalizedString(@"清空收藏夹", @"") forState:UIControlStateNormal];
            if(favlist==nil)
            {
                [NSThread detachNewThreadSelector:@selector(reloadDataInThreadByTag:) toTarget:self withObject:[NSNumber numberWithInt:kFavouriteHeaderTag]];
            }
            break;
        default:
            break;
    }
    UIBarButtonItem *barItem=[[UIBarButtonItem alloc] initWithCustomView:btn];
    self.navigationItem.leftBarButtonItem=barItem;
    [btn release];
    [barItem release];
}

#pragma mark - ScrollView Delegate
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if(scrollView.tag==kHistrtyTableViewTag)
    {
        [hisHeaderView egoRefreshScrollViewDidScroll:scrollView];
    }
    else {
        [favHeaderView egoRefreshScrollViewDidScroll:scrollView];
    }
}

-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    if(scrollView.tag==kHistrtyTableViewTag)
    {
        [hisHeaderView egoRefreshScrollViewDidEndDragging:scrollView];
    }
    else {
        [favHeaderView egoRefreshScrollViewDidEndDragging:scrollView];
    }
}

#pragma mark - egoRefreshDelegate
-(NSDate *)egoRefreshTableHeaderDataSourceLastUpdated:(EGORefreshTableHeaderView *)view
{
    return [NSDate date];
}

-(BOOL)egoRefreshTableHeaderDataSourceIsLoading:(EGORefreshTableHeaderView *)view
{
    if(view.tag==kHisttoryHeaderTag)
    {
        return isHistoryLoading;
    }
    else {
        return isFavLoading;
    }
}

-(void)reloadDataInThreadByTag:(NSNumber *)tag
{
    NSAutoreleasePool *pool=[[NSAutoreleasePool alloc] init];
    if([tag intValue]==kHisttoryHeaderTag)
    {
        isHistoryLoading=YES;
        self.hislist=[[[HistoryDAL sharedInstance] getHistorylist] retain];
    }
    else {
        isFavLoading=NO;
        self.favlist=[[[FavouriteDAL sharedInstance] getFavouritelist] retain];
    }
    [self performSelectorOnMainThread:@selector(reloadDataOnMainThreadByTag:) withObject:tag waitUntilDone:YES];
    [pool release];
}

-(void)reloadDataOnMainThreadByTag:(NSNumber *)tag
{
    if([tag intValue]==kHisttoryHeaderTag)
    {
        isHistoryLoading=NO;
        [hisTableView reloadData];
        [hisHeaderView egoRefreshScrollViewDataSourceDidFinishedLoading:hisTableView];
    }
    else {
        isFavLoading=NO;
        [favTableView reloadData];
        [favHeaderView egoRefreshScrollViewDataSourceDidFinishedLoading:favTableView];
    }
}

-(void)egoRefreshTableHeaderDidTriggerRefresh:(EGORefreshTableHeaderView *)view
{
    NSLog(@"asf");
//    [self reloadDataInThreadByTag:[NSNumber numberWithInt:view.tag]];
    [NSThread detachNewThreadSelector:@selector(reloadDataInThreadByTag:) toTarget:self withObject:[NSNumber numberWithInt:view.tag]];
}


-(void)cubeStateDidChanged:(CubeView *)cubeView cubeState:(NSNumber *)cubeState
{
    [hisTableView setCubeState:[cubeState intValue]];
    [favTableView setCubeState:[cubeState intValue]];
}

#pragma bannerViewDelegate
-(void)bannerViewWillLoadAd:(ADBannerView *)banner
{}

-(void)bannerViewDidLoadAd:(ADBannerView *)banner
{}

-(void)bannerViewActionDidFinish:(ADBannerView *)banner
{}

-(void)bannerView:(ADBannerView *)banner didFailToReceiveAdWithError:(NSError *)error
{}
@end
