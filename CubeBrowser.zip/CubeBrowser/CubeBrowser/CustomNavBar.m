//
//  CustomNavBar.m
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-10-23.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "CustomNavBar.h"
#import "CubeConstants.h"

@implementation CustomNavBar

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

-(BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event
{
    if(point.y>20&&point.y<60)
    {
        return YES;
    }
    return NO;
}

@end
