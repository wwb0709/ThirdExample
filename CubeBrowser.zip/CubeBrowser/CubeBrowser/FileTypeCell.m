//
//  FileTypeCell.m
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-9-12.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "FileTypeCell.h"

@implementation FileTypeCell

@synthesize fileImageView,lblFileName,lblFileDetail;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        UIImageView *bgImgView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"files_manager_bg.png"]];
        [bgImgView setFrame:CGRectMake(0, 0, self.frame.size.width,self.frame.size.height)];
        [self setBackgroundView:bgImgView];
        [bgImgView release];
        bgImgView=nil;
        
        
        fileImageView=[[UIImageView alloc] initWithFrame:CGRectMake(20, 0, 120, 70)];
        [self addSubview:fileImageView];
        
        
        lblFileName=[[UILabel alloc] initWithFrame:CGRectMake(150, 13, 150, 20)];
        [lblFileName setTextColor:[UIColor blackColor]];
        [lblFileName setBackgroundColor:[UIColor clearColor]];
        [lblFileName setFont:[UIFont systemFontOfSize:18]];
        [lblFileName setFont:[UIFont boldSystemFontOfSize:17]];
        [self addSubview:lblFileName];
        
        
        lblFileDetail=[[UILabel alloc] initWithFrame:CGRectMake(lblFileName.frame.origin.x, lblFileName.frame.origin.y+lblFileName.frame.size.height+4, lblFileName.frame.size.width, lblFileName.frame.size.height)];
        [lblFileDetail setBackgroundColor:[UIColor clearColor]];
        [lblFileDetail setTextColor:[UIColor grayColor]];
        [lblFileDetail setFont:[UIFont systemFontOfSize:15]];
        [self addSubview:lblFileDetail];
        
        float cellWidth=320;
        if([[UIDevice currentDevice] userInterfaceIdiom]==UIUserInterfaceIdiomPad)
        {
            cellWidth=768;
        }
        UIImageView *shadowImgView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"files_manager_shadow.png"]];
        [shadowImgView setFrame:CGRectMake(0, 0, cellWidth, self.frame.size.height)];
        [self addSubview:shadowImgView];
        [shadowImgView release];
        
        [self setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
        [self setSelectionStyle:UITableViewCellSelectionStyleNone];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)dealloc
{
    self.fileImageView=nil;
    self.lblFileName=nil;
    self.lblFileDetail=nil;
    [super dealloc];
}

@end
