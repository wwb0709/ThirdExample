//
//  BottomViewController.m
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-7-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "BottomViewController.h"
#import "CustomTableView.h"
#import "FileTypeCell.h"
#import "FileTranserModel.h"
#import "FileTypeModel.h"
#import "FileTranserHelper.h"
#import "FilelistViewController.h"
#import "CubeConstants.h"
#import "LocalFileDAL.h"

@interface BottomViewController ()
{
    BOOL isLoading;
}
@property(nonatomic,retain)CustomTableView *dataTableView;
@property(nonatomic,retain)NSMutableArray *datalist;
@property(nonatomic,retain)EGORefreshTableHeaderView *headerView;

-(void)loadAllFilesInThread;
-(void)goHome;
@end

@implementation BottomViewController

@synthesize dataTableView;
@synthesize datalist;
@synthesize headerView;
@synthesize delegate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)loadAllFilesInThread
{
    NSAutoreleasePool *pool=[[NSAutoreleasePool alloc] init];
    self.datalist=[[[LocalFileDAL sharedInstance] getAllTypeFiles] retain];//Why,I don't know
    [dataTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
    isLoading=NO;
    [headerView performSelectorOnMainThread:@selector(egoRefreshScrollViewDataSourceDidFinishedLoading:) withObject:dataTableView waitUntilDone:YES];
    [pool release];
}

-(void)goHome
{
    if([delegate respondsToSelector:@selector(cubeStateDidChanged:cubeState:)])
    {
        [delegate cubeViewClick:[NSNumber numberWithInt:CubeTopState] obj:nil];
    }
}

-(void)loadView
{
    [super loadView];
    [self.view setBackgroundColor:[UIColor lightGrayColor]];
    
    dataTableView=[[CustomTableView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height) style:UITableViewStylePlain];
    [dataTableView setDataSource:self];
    [dataTableView setDelegate:self];
    [dataTableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    [self.view addSubview:dataTableView];
    
       
    
    headerView=[[EGORefreshTableHeaderView alloc] initWithFrame:CGRectMake(0, 0-dataTableView.frame.size.height, dataTableView.frame.size.width, dataTableView.frame.size.height)];
    [headerView setDelegate:self];
    [dataTableView addSubview:headerView];
    
   
    
    if([[UIDevice currentDevice] userInterfaceIdiom]==UIUserInterfaceIdiomPad)
    {
        UIImageView *imgView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"iTUnesArtwork.png"]];
        [imgView setFrame:CGRectMake(0, 290, self.view.frame.size.width, 780)];
        [dataTableView addSubview:imgView];
        [imgView release];
//        [dataTableView setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"iTunesArtWork.png"]]];
    }
    else {
        UIImageView *bgImgView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"lbs_tab_bg.png"]];
        [bgImgView setFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
        [dataTableView setBackgroundView:bgImgView];
        [bgImgView release];
        
        UIImageView *bottomImgView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"files_manager_bottom_shadow.png"]];
        [bottomImgView setFrame:CGRectMake(0, 420, self.view.frame.size.width, 50)];
        [dataTableView addSubview:bottomImgView];
        [bottomImgView release];
        
        
        UIImageView *bottomTextImgView=[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"files_manager_bottom_tips.png"]];
        [bottomTextImgView setFrame:CGRectMake(55, 440, 210, 24)];
        [dataTableView addSubview:bottomTextImgView];
        [bottomTextImgView release];
    } 
   
    UIButton *btnHome=[[[UIButton alloc] initWithFrame:CGRectMake(0, 0, 66, 32)] autorelease];
    [btnHome.titleLabel setFont:[UIFont boldSystemFontOfSize:13]];
    [btnHome setBackgroundImage:[UIImage imageNamed:@"account_button.png"] forState:UIControlStateNormal];
    [btnHome setTitle:NSLocalizedString(@"主页", @"") forState:UIControlStateNormal];
    [btnHome addTarget:self action:@selector(goHome) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.rightBarButtonItem=[[[UIBarButtonItem alloc] initWithCustomView:btnHome] autorelease];
    [btnHome release];
    
    [dataTableView setCubeState:CubeBottomState];

    
    self.datalist=[[[NSMutableArray alloc] init] autorelease];
    [NSThread detachNewThreadSelector:@selector(loadAllFilesInThread) toTarget:self withObject:nil];
}

-(void)releaseData
{
    self.datalist=nil;
    self.dataTableView=nil;
    self.headerView=nil;
}

-(void)dealloc
{
    self.delegate=nil;
    [self releaseData];
    [super dealloc];
}

- (void)viewDidUnload
{
    [self releaseData];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

-(void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    [self.view setHidden:YES];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.view setHidden:NO];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"底部的视图滑动处理");
}

-(BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event
{
    return NO;
    CGFloat touchHeight=15;
    CGRect bottomRect=CGRectMake(0, 29, self.view.frame.size.width, touchHeight);
    if(CGRectContainsPoint(bottomRect, point))
    {
        return NO;
    }
    
    return YES;
}

#pragma mark - tableView DataSource
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [datalist count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier=@"CellIdentifier";
    FileTypeCell *cell=[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(!cell)
    {
        cell=[[[FileTypeCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cellIdentifier] autorelease];
    }
    FileTypeModel *file=[datalist objectAtIndex:indexPath.row];
    NSLog(@"%@",file);
    cell.lblFileName.text=NSLocalizedString(file.fileTypeName, @"");
    cell.lblFileDetail.text=file.fileTypeDetail;
    cell.fileImageView.image=[UIImage imageNamed:file.fileImgURL];
    return cell;
}

#pragma mark - DataTableView Deleagte
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 70;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    FileTypeModel *typeFile=[datalist objectAtIndex:indexPath.row];
    FilelistViewController *fileVController=[[FilelistViewController alloc] initWithFileType:typeFile];
    [self.navigationController pushViewController:fileVController animated:YES];
    [fileVController release];
}

-(void)cubeStateDidChanged:(CubeView *)cubeView cubeState:(NSNumber *)cubeState
{
    [dataTableView setCubeState:[cubeState intValue]];
}

#pragma mark -EGOHeaderDelegate
-(BOOL)egoRefreshTableHeaderDataSourceIsLoading:(EGORefreshTableHeaderView *)view
{
    return isLoading;
}

-(NSDate *)egoRefreshTableHeaderDataSourceLastUpdated:(EGORefreshTableHeaderView *)view
{
    return [NSDate date];
}

-(void)egoRefreshTableHeaderDidTriggerRefresh:(EGORefreshTableHeaderView *)view
{
    isLoading=YES;
    [NSThread detachNewThreadSelector:@selector(loadAllFilesInThread) toTarget:self withObject:nil];
}


#pragma mark - ScrollView Delegate
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    [headerView egoRefreshScrollViewDidScroll:scrollView];
}
-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    [headerView egoRefreshScrollViewDidEndDragging:scrollView];
}
@end
