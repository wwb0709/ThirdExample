//
//  MainViewController.h
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-7-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CubeViewClickDelegate.h"

@class CubeView;

@interface MainViewController : UIViewController<CubeViewClickDelegate>

@property(nonatomic,retain)CubeView *cube;
@end
