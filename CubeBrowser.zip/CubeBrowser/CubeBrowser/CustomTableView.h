//
//  CustomTableView.h
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-9-1.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//


#import <UIKit/UIKit.h>
#import "CubeView.h"
#import "CubeConstants.h"

@interface CustomTableView : UITableView<UIScrollViewDelegate>
{
}


@property(nonatomic,assign)CubeState cubeState;;
@end
