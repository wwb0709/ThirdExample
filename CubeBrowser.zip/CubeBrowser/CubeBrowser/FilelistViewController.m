//
//  FilelistViewController.m
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-9-16.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "FilelistViewController.h"
#import "FileTranserModel.h"
#import "LocalFileDAL.h"
#import "FileTypeModel.h"
#import "FileTranserHelper.h"
#import "FileDetailViewController.h"


@interface FilelistViewController ()
{
}

@property(nonatomic,retain)MBProgressHUD *hudView;
@property(nonatomic,retain)FileTypeModel *typeFile;
@property(nonatomic,retain)UITableView *dataTableView;
@property(nonatomic,retain)NSMutableArray *datalist;

-(void)loadTypeFileInThread;
-(void)backAction:(id)sender;
-(void)deleteFileByURL:(NSString *)url;

@end

@implementation FilelistViewController

@synthesize datalist,dataTableView,typeFile;
@synthesize hudView;

-(id)initWithFileType:(FileTypeModel *)fileType
{
    self=[super init];
    if(self)
    {
        typeFile=[fileType retain];
        self.navigationItem.title=typeFile.fileTypeName;
    }
    return self;
}

-(void)backAction:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)loadTypeFileInThread
{
    NSAutoreleasePool *pool=[NSAutoreleasePool alloc];
    self.datalist=[[LocalFileDAL sharedInstance] getFileByTypeName:typeFile.fileTypeName];
    [dataTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
    [pool release];
}
-(void)loadView
{
    [super loadView];
    
    UIButton *btn=[[UIButton alloc] initWithFrame:CGRectMake(0, 0, 62, 28)];
    [btn setBackgroundImage:[UIImage imageNamed:@"tbar_back.png"] forState:UIControlStateNormal];
    [btn setBackgroundImage:[UIImage imageNamed:@"tbar_back_down.png"] forState:UIControlStateHighlighted];
    [btn addTarget:self action:@selector(backAction:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *backBarItem=[[UIBarButtonItem alloc] initWithCustomView:btn];
    self.navigationItem.leftBarButtonItem=backBarItem;
    [btn release];
    [backBarItem release];
    
    
    dataTableView=[[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    [dataTableView setDelegate:self];
    [dataTableView setDataSource:self];
    [self.view addSubview:dataTableView];
    
    
    self.datalist=[[[NSMutableArray alloc] init] autorelease];
    [NSThread detachNewThreadSelector:@selector(loadTypeFileInThread) toTarget:self withObject:nil];
}

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [dataTableView deselectRowAtIndexPath:[dataTableView indexPathForSelectedRow] animated:YES];
}

-(void)releaseCache
{
    self.dataTableView=nil;
    self.datalist=nil;
}

-(void)dealloc
{
    [self releaseCache];
    typeFile=nil;
    self.hudView.delegate=nil;
    self.hudView=nil;
    [super dealloc];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    [self releaseCache];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - tableDataSource
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [datalist count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier=@"CellIdentifier";
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(cell==nil)
    {
        cell=[[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier] autorelease];
        [cell setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
    }
    FileTranserModel *file=[datalist objectAtIndex:indexPath.row];
    cell.textLabel.text=file.fileName;
    cell.detailTextLabel.text=[NSString stringWithFormat:@"%@",[[FileTranserHelper sharedInstance]getFileSizeString:file.fileTrueSize]];
    return cell;
}

#pragma mark - tableView DataSource
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    FileTranserModel *file=[datalist objectAtIndex:indexPath.row];
    FileDetailViewController *detailVCOntroller=[[FileDetailViewController alloc] initWithFileType:file];
    [self.navigationController pushViewController:detailVCOntroller animated:YES];
    [detailVCOntroller release];
}

-(BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

-(void)deleteFileByURL:(NSString *)url
{
    NSAutoreleasePool *pool=[[NSAutoreleasePool alloc] init];
    NSFileManager *fileManager=[NSFileManager defaultManager];
    [fileManager removeItemAtPath:url error:nil];
    [dataTableView performSelectorOnMainThread:@selector(reloadData) withObject:nil waitUntilDone:YES];
    [pool release];
}

-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(editingStyle==UITableViewCellEditingStyleDelete)
    {
        FileTranserModel *file=[datalist objectAtIndex:indexPath.row];
        self.hudView=[[[MBProgressHUD alloc] initWithView:self.view] autorelease];
        [hudView setLabelText:@"请稍后..."];
        [hudView setRemoveFromSuperViewOnHide:YES];
        [hudView showWhileExecuting:@selector(deleteFileByURL:) onTarget:self withObject:file.destationPath animated:YES];
        [self.view addSubview:hudView];
    }
}
@end
