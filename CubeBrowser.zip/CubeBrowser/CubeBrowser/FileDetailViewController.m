//
//  FileDetailViewController.m
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-9-16.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "FileDetailViewController.h"
#import "FileTypeModel.h"
#import "FileTranserModel.h"
#import "SCGIFImageView.h"

@interface FileDetailViewController ()

@property(nonatomic,retain)FileTranserModel *fileTranserModel;
@property(nonatomic,retain)UIImageView *imageView;
@property(nonatomic,retain)UIScrollView *scrollView;
@property(nonatomic,retain)MPMoviePlayerController *moviewVCtrolle;
@property(nonatomic,retain)AVAudioPlayer *audioPlayer;
@property(nonatomic,retain)UIWebView *webView;

-(void)backAction:(id)sender;
-(void)playVedioInThread:(NSString *)url;

@end

@implementation FileDetailViewController

@synthesize imageView;
@synthesize fileTranserModel;
@synthesize scrollView;
@synthesize moviewVCtrolle;
@synthesize audioPlayer;
@synthesize webView;

-(id)initWithFileType:(FileTranserModel *)fileType
{
    if(self=[super init])
    {
        fileTranserModel=[fileType retain];
        self.navigationItem.title=fileTranserModel.fileName;
    }
    return self;
}

-(void)playVedioInThread:(NSString *)url
{
    
}
-(void)backAction:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}


-(void)loadView
{
    [super loadView];
    
    UIButton *btn=[[UIButton alloc] initWithFrame:CGRectMake(0, 0, 62, 28)];
    [btn setBackgroundImage:[UIImage imageNamed:@"tbar_back.png"] forState:UIControlStateNormal];
    [btn setBackgroundImage:[UIImage imageNamed:@"tbar_back_down.png"] forState:UIControlStateHighlighted];
    [btn addTarget:self action:@selector(backAction:) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *backBarItem=[[UIBarButtonItem alloc] initWithCustomView:btn];
    self.navigationItem.leftBarButtonItem=backBarItem;
    [btn release];
    [backBarItem release];
    
    [self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"fileDetail_bg.png"]]];
    
    NSURL *url=[NSURL fileURLWithPath:fileTranserModel.destationPath];
    NSURL *suffixURL=[[[NSBundle mainBundle] resourceURL] URLByAppendingPathComponent:@"Suffix.plist"];
    NSDictionary *dict=[NSDictionary dictionaryWithContentsOfURL:suffixURL];
    NSString *suffix=fileTranserModel.fileName.lastPathComponent;
    
    BOOL isPic=NO;
    //是否加载scrollView
    NSDictionary *picDic=[dict objectForKey:@"图片"];
    NSArray *piclist=[picDic objectForKey:@"Suffix"];
    NSLog(@"piclist=%@",piclist);
    for(NSString *str in piclist)
    {
        if([suffix hasSuffix:str])
        {
            isPic=YES;
        }
    }
    //静态图
    if(isPic)
    {
        UIImage *img=[[UIImage alloc] initWithContentsOfFile:fileTranserModel.destationPath];
        imageView=[[UIImageView alloc] initWithImage:img];
        [imageView setFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-44)];
    }
    
    
    
    BOOL isGif=NO;
    NSDictionary *gifDict=[dict objectForKey:@"动态图"];
    NSArray *giflist=[gifDict objectForKey:@"Suffix"];
    for(NSString *str in giflist)
    {
        if([suffix hasSuffix:str])
        {
            isGif=YES;
        }
    }
    //gif
    if(isGif)
    {
        NSData *data=[[NSData alloc] initWithContentsOfFile:fileTranserModel.destationPath];
        imageView=[[SCGIFImageView alloc] initWithGIFData:data];
        [imageView setFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-44)];
        [data release];
    }
    if(isGif||isPic)
    {
        scrollView=[[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-44)];
        [scrollView setDelegate:self];
        [scrollView setMinimumZoomScale:1];
        [scrollView setMaximumZoomScale:3];
        [scrollView addSubview:imageView];
        [self.view addSubview:scrollView];
    }

    
    
    BOOL isVedio=NO;
    NSDictionary *vedioDict=[dict objectForKey:@"视频"];
    NSArray *vediolist=[vedioDict objectForKey:@"Suffix"];
    for(NSString *str in vediolist)
    {
        if([suffix hasSuffix:str])
        {
            isVedio=YES;
        }
    }
    //视频
    if(isVedio)
    {
        moviewVCtrolle=[[MPMoviePlayerController alloc] initWithContentURL:url];
        [moviewVCtrolle.view setFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-44)];
        [self.view addSubview:moviewVCtrolle.view];
        [moviewVCtrolle play];
    }
    
    
    
    BOOL isMusic=NO;
    NSDictionary *musicDict=[dict objectForKey:@"音频"];
    NSArray *musiclist=[musicDict objectForKey:@"Suffix"];
    for(NSString *str in musiclist)
    {
        if([suffix hasSuffix:str])
        {
            isMusic=YES;
        }
    }
    //音频
    if(isMusic)
    {
        audioPlayer=[[AVAudioPlayer alloc] initWithContentsOfURL:url error:nil];
        [audioPlayer play];
    }
    
    
    BOOL isDoc=NO;
    NSDictionary *docDict=[dict objectForKey:@"文档"];
    NSArray *doclist=[docDict objectForKey:@"Suffix"];
    for(NSString *str in doclist)
    {
        if([suffix hasSuffix:str])
        {
            isDoc=YES;
        }
    }

    //文档
    if(isDoc)
    {
        webView=[[UIWebView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-44)];
        [webView setScalesPageToFit:YES];
        [webView setDelegate:self];
        [self.view addSubview:webView];
        NSURLRequest *request=[NSURLRequest requestWithURL:url];
        [self.webView loadRequest:request];
    }
}

-(void)releaseCache
{
    self.webView=nil;
    self.imageView=nil;
    self.scrollView=nil;
    [self.moviewVCtrolle stop];
    self.moviewVCtrolle=nil;
    [self.audioPlayer stop];
    self.audioPlayer=nil;
}

-(void)dealloc
{
    [self releaseCache];
    self.fileTranserModel=nil;
    [super dealloc];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    [self releaseCache];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma scrollView Delegate
-(UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView
{
    return imageView;
}

#pragma webView delegate
-(void)webViewDidStartLoad:(UIWebView *)_webView
{
    UIActivityIndicatorView *actView=[[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    [actView setFrame:CGRectMake(0, 0, 20, 20)];
    [actView setCenter:_webView.center];
    [actView setTag:500];
    [_webView addSubview:actView];
    [actView startAnimating];
    [actView release];
}

-(void)webView:(UIWebView *)_webView didFailLoadWithError:(NSError *)error
{
    UIActivityIndicatorView *actView=(UIActivityIndicatorView *)[_webView viewWithTag:500];
    if(actView!=nil)
    {
        [actView removeFromSuperview];
    }
}

-(void)webViewDidFinishLoad:(UIWebView *)_webView
{
    UIActivityIndicatorView *actView=(UIActivityIndicatorView *)[_webView viewWithTag:500];
    if(actView!=nil)
    {
        [actView removeFromSuperview];
    }

}

@end
