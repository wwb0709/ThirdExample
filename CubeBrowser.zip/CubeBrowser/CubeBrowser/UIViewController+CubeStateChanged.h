//
//  UIViewController+CubeStateChanged.h
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-9-15.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//


@class CubeView;
@interface UIViewController (CubeStateChanged)


-(void)cubeStateDidChanged:(CubeView *)cubeView cubeState:(NSNumber *)cubeState;

@end
