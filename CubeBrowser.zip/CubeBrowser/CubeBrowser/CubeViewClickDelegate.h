//
//  CubeViewClickDelegate.h
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-9-17.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CubeConstants.h"

@protocol CubeViewClickDelegate <NSObject>

@optional
-(void)cubeViewClick:(NSNumber *)cubeStateClick obj:(id)obj;

@end
