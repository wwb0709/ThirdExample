//
//  AppDelegate.h
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-7-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioToolbox.h>
#import "WeiboWrapper.h"
#import "MainViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@property (nonatomic, retain) WeiboCommonAPI *weiboApi;
@property(nonatomic,assign)SystemSoundID pull_pull;
@property(nonatomic,assign)SystemSoundID pull_release;
@property(nonatomic,retain)MainViewController *mainViewController;

-(void)publishMessageResult:(NSNotification*)notification;
@end
