//
//  MainViewController.m
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-7-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "MainViewController.h"
#import "CubeView.h"
#import "FrontViewController.h"
#import "LeftViewController.h"
#import "TopViewController.h"
#import "RightViewController.h"
#import "BottomViewController.h"
#import "UINavigationBar+BackImage.h"

@interface MainViewController ()

@property(nonatomic,retain)FrontViewController *fontVController;
@end

@implementation MainViewController

@synthesize cube;
@synthesize fontVController;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    fontVController=[[FrontViewController alloc] init];
    LeftViewController *leftVController=[[LeftViewController alloc] init];
    [leftVController setDelegate:self];
    leftVController.navigationItem.title=NSLocalizedString(@"历史记录", @"");
    UINavigationController *leftNavController=[[UINavigationController alloc] initWithRootViewController:leftVController];
    if([[[UIDevice currentDevice] systemVersion] intValue]>=5)
    {
        [leftNavController.navigationBar setBackgroundImage:[UIImage imageNamed:@"top_bg.png"] forBarMetrics:UIBarMetricsDefault];
    }
    
    RightViewController *rightVController=[[RightViewController alloc]init];
    [rightVController setDelegate:self];
    TopViewController *topVController=[[TopViewController alloc] init];
    [topVController setDelegate:self];
    topVController.navigationItem.title=NSLocalizedString(@"软件设置", @"");
    UINavigationController *topNavController=[[UINavigationController alloc] initWithRootViewController:topVController];
    if([[[UIDevice currentDevice] systemVersion] intValue]>=5)
    {
        [topNavController.navigationBar setBackgroundImage:[UIImage imageNamed:@"top_bg.png"] forBarMetrics:UIBarMetricsDefault];
    }
    
    
    BottomViewController *bottomVController=[[BottomViewController alloc] init];
    [bottomVController setDelegate:self];
    bottomVController.navigationItem.title=NSLocalizedString(@"已下载列表", @"");
    UINavigationController *bottomNavController=[[UINavigationController alloc] initWithRootViewController:bottomVController];
    if([[[UIDevice currentDevice] systemVersion] intValue]>=5)
    {
        [bottomNavController.navigationBar setBackgroundImage:[UIImage imageNamed:@"top_bg.png"] forBarMetrics:UIBarMetricsDefault];
    }
                                                 
    NSArray *viewlist=[NSArray arrayWithObjects:topNavController,fontVController,bottomNavController,leftNavController,rightVController, nil];
    [topVController release];
    [topNavController release];
    [leftVController release];
    [leftNavController release];
    [rightVController release];
    [bottomVController release];
    [bottomNavController release];
    
    cube=[[CubeView alloc] init];
    [cube setViewlist:viewlist];
    [cube reloadViewControllers];
    [self.view addSubview:cube];
    [self.view setBackgroundColor:[UIColor blackColor]];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    self.cube=nil;
    self.fontVController=nil;
}

-(void)dealloc
{
    self.fontVController=nil;
    self.cube=nil;
    [super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"主视图处理了滑动事件");
}


#pragma mark CubeViewDelegate
-(void)cubeViewClick:(NSNumber *)cubeStateClick obj:(id)obj
{
    [cube setCubeState:CubeFrontState];
    [UIView beginAnimations:nil context:nil];
    if([cubeStateClick intValue]==CubeLeftState)
    {

        [cube rotateCubeWithDirection:SwipeLeftToRightDirection rotatedDegree:0];
       
    }
    if([cubeStateClick intValue]==CubeTopState)
    {
       
        [cube rotateCubeWithDirection:SwipeBottomToTopDirection rotatedDegree:0];


    }
    [UIView commitAnimations];
    if(obj!=nil)
    {
        [fontVController.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:obj]]];
    }
    [cube showViewController:[NSNumber numberWithInt:CubeFrontState]];
}

@end
