//
//  CustomToolbar.m
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-8-31.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "CustomToolbar.h"

@implementation CustomToolbar

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

-(id)hitTest:(CGPoint)point withEvent:(UIEvent *)event 
{
    UIView *hitView = [super hitTest:point withEvent:event];
    if (hitView == self)   
    {
        return nil;
    }
    else    
    {
        return hitView;   
    }
}

-(BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event
{
    CGFloat touchHeight=15;
    CGRect bottomRect=CGRectMake(0, 29, self.frame.size.width, touchHeight);
    if(CGRectContainsPoint(bottomRect, point))
    {
        return NO;
    }

    return YES;
}

@end
