//
//  LocalFileDAL.h
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-9-16.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CubeConstants.h"


@interface LocalFileDAL : NSObject
{}

+(LocalFileDAL *)sharedInstance;

-(NSMutableArray *)getAllTypeFiles;
-(NSMutableArray *)getFileByTypeName:(NSString *)typeName;

@end
