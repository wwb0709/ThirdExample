//
//  UINavigationBar+BackImage.m
//  -巴士商店-
//
//  Created by TGBUS on 12-3-16.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "UINavigationBar+BackImage.h"
#import "CubeConstants.h"

@implementation UINavigationBar (BackImage)

- (void)drawRect:(CGRect)rect {  
    [super drawRect:rect];
    if([[UIDevice currentDevice] userInterfaceIdiom]==UIUserInterfaceIdiomPhone)
    {
        UIImage *image = [UIImage imageNamed: @"top_bg.png"];  
        [image drawInRect:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];  
    }
    else
    {
        UIImage *image=[UIImage imageNamed:@"ipad_top_bg2_noshadow.png"];
        [image drawInRect:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
    }
}  

-(BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event
{
    if((point.x<kResponseWidth+30||point.x>320-kResponseWidth-30)&&point.y<44)
    {
        return YES;
    }
    return NO;
    }
@end
