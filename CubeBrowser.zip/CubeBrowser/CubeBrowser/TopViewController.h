//
//  TopViewController.h
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-7-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Twitter/Twitter.h>
#import "WeiboWrapper.h"
#import <MessageUI/MessageUI.h>
#import <MediaPlayer/MediaPlayer.h>
#import "CubeViewClickDelegate.h"

@class CustomTableView;

@interface TopViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,UIActionSheetDelegate,MFMessageComposeViewControllerDelegate,MFMailComposeViewControllerDelegate>

@property(nonatomic,assign)id<CubeViewClickDelegate>delegate;
@property(nonatomic,retain)CustomTableView *settingTableView;
@property(nonatomic,retain)NSMutableArray *settinglist;

@end
