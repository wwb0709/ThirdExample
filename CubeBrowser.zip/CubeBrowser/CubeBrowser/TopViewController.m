//
//  TopViewController.m
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-7-29.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "TopViewController.h"
#import "CustomTableView.h"
#import "SettingDAL.h"
#import "AppDelegate.h"
#import "UINavigationBar+BackImage.h"

#define kSwitchRockTag 500

@interface TopViewController ()
-(void)switchAction:(id)sender;
-(void)goHome;
@end

@implementation TopViewController

@synthesize delegate;
@synthesize settingTableView;
@synthesize settinglist;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)goHome
{
    if([delegate respondsToSelector:@selector(cubeStateDidChanged:cubeState:)])
    {
        [delegate cubeViewClick:[NSNumber numberWithInt:CubeTopState] obj:nil];
    }
}

-(void)loadView
{
    [super loadView];
    [self.view setBackgroundColor:[UIColor grayColor]];
    settingTableView=[[CustomTableView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-44) style:UITableViewStyleGrouped];
    [settingTableView setDelegate:self];
    [settingTableView setDataSource:self];
    [self.view addSubview:settingTableView];
    
    
    settinglist=[[NSMutableArray alloc] init];
    
    NSMutableArray *firstlist=[[NSMutableArray alloc] init];
    [firstlist addObject:NSLocalizedString(@"甩动翻转正方体", @"")];
    [settinglist addObject:firstlist];
    [firstlist release];
    
    NSMutableArray *sharelist=[[NSMutableArray alloc] init];
    [sharelist addObject:NSLocalizedString(@"分享到Twitter", @"")];
    [sharelist addObject:NSLocalizedString(@"分享到新浪、搜狐、腾讯、网易", @"")];
    [sharelist addObject:NSLocalizedString(@"短信分享", @"")];
    [sharelist addObject:NSLocalizedString(@"邮件分享", @"")];
    [settinglist addObject:sharelist];
    [sharelist release];
    
    NSMutableArray *secondlist=[[NSMutableArray alloc] init];
    [secondlist addObject:NSLocalizedString(@"演示视频", @"")];
    [settinglist addObject:secondlist];
    [secondlist release];
    
    //关于我们
    NSMutableArray *uslist=[[NSMutableArray alloc] init];
    [uslist addObject:NSLocalizedString(@"关于软件", @"")];
    [settinglist addObject:uslist];
    [uslist release];
    
    UIButton *btnHome=[[[UIButton alloc] initWithFrame:CGRectMake(0, 0, 66, 32)] autorelease];
    [btnHome.titleLabel setFont:[UIFont boldSystemFontOfSize:13]];
    [btnHome setBackgroundImage:[UIImage imageNamed:@"account_button.png"] forState:UIControlStateNormal];
    [btnHome setTitle:NSLocalizedString(@"主页", @"") forState:UIControlStateNormal];
    [btnHome addTarget:self action:@selector(goHome) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.rightBarButtonItem=[[[UIBarButtonItem alloc] initWithCustomView:btnHome] autorelease];
    [btnHome release];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.view setHidden:NO];
}

-(void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    [self.view setHidden:YES];
}


-(void)releaseCache
{
    self.settingTableView=nil;
    self.delegate=nil;
}

-(void)dealloc
{
    [self releaseCache];
    [super dealloc];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    [self releaseCache];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


#pragma mark tableView Delegate
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [settinglist count];
}

#pragma mark tableView DataSource
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[settinglist objectAtIndex:section] count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier=@"CellIdentifier";
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if(!cell)
    {
        cell=[[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cellIdentifier] autorelease];
    }
    NSMutableArray *datalist=[settinglist objectAtIndex:indexPath.section];
    NSString *dataString=[[datalist objectAtIndex:indexPath.row] description];
    if([dataString isEqualToString:NSLocalizedString(@"甩动翻转正方体", @"")])
    {
        UISwitch *switchView=[[UISwitch alloc]initWithFrame:CGRectMake(220, 8, 50, 23)];
        [switchView setOn:[SettingDAL shouldRockRotate]];
        [switchView addTarget:self action:@selector(switchAction:) forControlEvents:UIControlEventValueChanged];
        [switchView setTag:kSwitchRockTag];
        [cell addSubview:switchView];
        [switchView release];
    }
    if(indexPath.section!=0)
    {
        cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    }
    cell.textLabel.text=dataString;
    return cell;
}

-(void)switchAction:(id)sender
{
    UISwitch *switchView=(UISwitch *)sender;
    switch (switchView.tag) {
        case kSwitchRockTag:
            [SettingDAL setRockRotate:switchView.isOn];
            break;
            
        default:
            break;
    }
}

#pragma mark tableView delegate
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if(indexPath.section==1)
    {
        if(indexPath.row==0)//Twitter
        {
            if ([[[UIDevice currentDevice] systemVersion] floatValue] < 5) {
                UIAlertView *av = [[UIAlertView alloc] initWithTitle:@"Error" message:NSLocalizedString(@"Now Support Twitter Share function in iOS5 ONLY",@"") delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
                [av show];
                [av release];
                
                return;
            }
            TWTweetComposeViewController *tweetViewContoller=[[TWTweetComposeViewController alloc] init];
            NSString *postTest=NSLocalizedString(@"postText", @"");
            [tweetViewContoller setInitialText:postTest];
            
            NSString *url=[[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"iTunesArtWork.jpg"];
            UIImage *img=[[UIImage alloc] initWithContentsOfFile:url];
            [tweetViewContoller addImage:img];
            [img release];
            [self presentModalViewController:tweetViewContoller animated:YES];
            [tweetViewContoller release];
        }
        if(indexPath.row==1)//新浪
        {
            UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:NSLocalizedString(@"分享到", @"") delegate:self cancelButtonTitle:NSLocalizedString(@"取消", @"") destructiveButtonTitle:nil otherButtonTitles:NSLocalizedString(@"新浪微博", @""),NSLocalizedString(@"网易微博",@""),NSLocalizedString(@"腾讯微博", @""),NSLocalizedString(@"搜狐微博", @""),NSLocalizedString(@"分享设置",@""), nil];
            [actionSheet setActionSheetStyle:UIActionSheetStyleBlackTranslucent];
            if([[UIDevice currentDevice] userInterfaceIdiom]==UIUserInterfaceIdiomPhone)
            {
                AppDelegate *appDelegate=(AppDelegate *)[[UIApplication sharedApplication]delegate];
                [actionSheet showInView:appDelegate.window];
            }
            else {
                [actionSheet showInView:self.view];
            }
            [actionSheet release];            
        }
        
        if(indexPath.row==2)//短信
        {
                Class messageClass = (NSClassFromString(@"MFMessageComposeViewController"));
                NSLog(@"can send SMS [%d]", [messageClass canSendText]);
                
            if (![messageClass canSendText]) {
                [self messageShow: NSLocalizedString(@"设备没有短信功能", @"")];
                return;
            }
            MFMessageComposeViewController *messagePicker=[[MFMessageComposeViewController alloc] init];
            messagePicker.messageComposeDelegate=self;
            [messagePicker setBody:NSLocalizedString(@"postText", @"")];
            AppDelegate *appDelegate=(AppDelegate *)[[UIApplication sharedApplication]delegate];
            [appDelegate.window.rootViewController presentModalViewController:messagePicker animated:YES];
//            [self presentModalViewController:messagePicker animated:YES];
            [[UIApplication sharedApplication] setStatusBarHidden:YES];
            [messagePicker release];
        }
        if(indexPath.row==3)//邮件
        {
            [self emailSend];   
        }
    }
    if(indexPath.section==2)
    {
        
        if([delegate respondsToSelector:@selector(cubeViewClick:obj:)])
        {
            [delegate cubeViewClick:[NSNumber numberWithInt:CubeTopState] obj:@"http://www.manhuazhuo.com/cubebrowser_help.mp4"];
        }
        
    }
    if(indexPath.section==3)
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:NSLocalizedString(@"关于软件", @"")  message:NSLocalizedString(@"about_info",@"") delegate:self cancelButtonTitle:NSLocalizedString(@"好", @"")  otherButtonTitles:nil];
        [alert show];
        [alert release];
    }
}
-(void)emailSend{
    
    if (![MFMailComposeViewController canSendMail]) {
        [self messageShow:NSLocalizedString(@"您的设备不支持发送邮件", @"")];
        return;
    }
        MFMailComposeViewController *picker = [[MFMailComposeViewController alloc] init];
        
        picker.mailComposeDelegate = self; 

        
        NSURL *url=[[[NSBundle mainBundle] resourceURL] URLByAppendingPathComponent:@"iTunesArtwork.jpg"];
        NSData *imageData = [[NSData alloc] initWithContentsOfURL:url];
        
        if (imageData!=nil) 
        {       
            [picker addAttachmentData:imageData mimeType:@"image/jpg" fileName:@"＊＊＊＊＊.jpg"];
        }
        [imageData release];
        
        [picker setMessageBody:NSLocalizedString(@"postText", @"") isHTML:YES]; 
        picker.navigationBar.barStyle = UIBarStyleBlack;
        
    AppDelegate *appDelegate=(AppDelegate *)[[UIApplication sharedApplication]delegate];
    [appDelegate.window.rootViewController presentModalViewController:picker animated:YES];
        
    [picker release];
}


-(void)messageShow:(NSString *)msg{
    
    UIAlertView *av=[[UIAlertView alloc] initWithTitle:msg message:nil delegate:nil cancelButtonTitle:NSLocalizedString(@"好", @"") otherButtonTitles:nil];
    
    [av show];
    
    [av release];
    
}


- (void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *) error{
    
    AppDelegate *appDelegate=(AppDelegate *)[[UIApplication sharedApplication]delegate];
    switch (result) { 
            
        case MFMailComposeResultCancelled: 
            
//            [self messageShow:NSLocalizedString(@"郵件已取消！", @"")];
            
            break; 
            
        case MFMailComposeResultSaved: 
            
            [self messageShow:NSLocalizedString(@"邮件已保存！", @"")];
            
            break; 
            
        case MFMailComposeResultSent: 
            
            [self messageShow:NSLocalizedString(@"邮件发送成功！", @"")];
            
            break; 
            
        case MFMailComposeResultFailed: 
            
            [self messageShow:NSLocalizedString(@"邮件发送失敗！", @"")];
            
            break; 
            
    } 
    
    [appDelegate.window.rootViewController dismissModalViewControllerAnimated:YES]; 
}

-(void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result
{
    switch (result) {
        case MessageComposeResultSent:
            [self messageShow:NSLocalizedString(@"短信发送成功", @"")];
            break;
        case MessageComposeResultFailed:
            [self messageShow:NSLocalizedString(@"短信发送失败", @"")];
            break;
        case MessageComposeResultCancelled:
            break;
        default:
            break;
    }
    AppDelegate *appDelegate=(AppDelegate *)[[UIApplication sharedApplication]delegate];
    [appDelegate.window.rootViewController dismissModalViewControllerAnimated:YES];
}

// 网易demo方法
- (void)buttonShareClicked:(int)tag {
    
    //图片要用jpg格式，苹果会把png格式的图片加密，无法获取了
    NSString *imagePath = @"Icon.jpg";
    NSString *message = NSLocalizedString(@"postText", @"");
    switch (tag) {
        case 0:
            //            [WeiboWrapper publishMessage:@"分享的内容" andWeiboId:Weibo_Sina andController:self andUserData:0];
            [WeiboWrapper publishMessage:message andImagePath:imagePath andWeiboId:Weibo_Sina andController:self andUserData:0];
            break;
        case 1:
            //            [WeiboWrapper publishMessage:@"分享的内容" andWeiboId:Weibo_Tencent andController:self andUserData:0];
            [WeiboWrapper publishMessage:message andImagePath:imagePath andWeiboId:Weibo_Netease andController:self andUserData:0];
            break;
        case 2:
            //[WeiboWrapper publishMessage:@"分享的内容" andWeiboId:Weibo_Netease andController:self andUserData:0];
            [WeiboWrapper publishMessage:message andImagePath:imagePath andWeiboId:Weibo_Tencent andController:self andUserData:0];
            break;
        case 3:
            //            [WeiboWrapper publishMessage:@"分享的内容" andWeiboId:Weibo_Sohu andController:self andUserData:0];
            [WeiboWrapper publishMessage:message andImagePath:imagePath andWeiboId:Weibo_Sohu andController:self andUserData:0];
            break;
        case 4:
            [WeiboWrapper navigateToWeiboSettingController:self.navigationController];
            break;
        default:
            break;
    }
}

#pragma mark - ActionSheet delegate
-(void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0://新浪微博
        case 1://网易微博
        case 2://腾讯微博
        case 3://搜狐微博
            [self buttonShareClicked:buttonIndex];
            break;
        case 4://分享设置
            [self buttonShareClicked:buttonIndex];
        default:
            break;
    }
}

-(void)cubeStateDidChanged:(CubeView *)cubeView cubeState:(NSNumber *)cubeState
{
    [settingTableView setCubeState:[cubeState intValue]];
}
@end
