//
//  SettingDAL.m
//  CubeBrowser
//
//  Created by 国翔 韩 on 12-9-19.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "SettingDAL.h"

#define kRockRatate @"RockRotate"

@implementation SettingDAL

+(void)setRockRotate:(BOOL)flag
{
    NSUserDefaults *userDefault=[NSUserDefaults standardUserDefaults];
    [userDefault setBool:flag forKey:kRockRatate];
}

+(BOOL)shouldRockRotate
{
    NSUserDefaults *userDefault=[NSUserDefaults standardUserDefaults];
    return [[userDefault objectForKey:kRockRatate] boolValue];
}
@end
