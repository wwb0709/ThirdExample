//
//  FindlocationAppDelegate.h
//  Findlocation
//
//  Created by Administrator on 12-4-19.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class FindlocationViewController;

@interface FindlocationAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) FindlocationViewController *viewController;

@end
