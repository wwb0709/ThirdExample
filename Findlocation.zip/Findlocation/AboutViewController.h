//
//  AboutViewController.h
//  Findlocation
//
//  Created by Administrator on 12-4-20.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIButton *BackHome;

- (IBAction)BackHome:(id)sender;
@end
